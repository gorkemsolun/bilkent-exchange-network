"use client";

export default function Home() {
  return (
    <div>
      <img className="w-full h-full" src="cs319.png" alt="cs319" />
    </div>
  );
}
